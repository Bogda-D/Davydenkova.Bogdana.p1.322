package maingestorproyectos;

public enum TipoAnalisis {
    DESCRIPTIVO, 
    INFERENCIAL, 
    PREDICTIVO
}
