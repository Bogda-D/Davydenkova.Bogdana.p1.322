package maingestorproyectos;

public class SistemaVisualizacion extends Proyecto{
    
    private static int MIN_CANT_GRAFICOS = 1;
    private int cantidadGraficos;

    public SistemaVisualizacion(String nombre, String equipoResponsable, EstadoActual estadoActual, int cantidadGraficos) {
        super(nombre, equipoResponsable, estadoActual);
        this.cantidadGraficos = validarCantidadGraficos(cantidadGraficos);
    }
    
    private int validarCantidadGraficos(int cantidad){
        if(cantidad < MIN_CANT_GRAFICOS){
            throw new IllegalArgumentException("Cantidad de graficos invalida");
        }else{
            return cantidad;
        }
    }
    
    public String mostrarProyecto() {
        return super.mostrarProyecto() + "Cantidad de graficos %-8s |\n".formatted(cantidadGraficos);
    }
    
    
    
}
