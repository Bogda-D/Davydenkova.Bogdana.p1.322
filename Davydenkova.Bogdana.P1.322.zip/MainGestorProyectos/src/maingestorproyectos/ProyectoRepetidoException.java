package maingestorproyectos;

public class ProyectoRepetidoException extends RuntimeException {

    private static final String MESSAGE = "Proyecto Repetido";

    public ProyectoRepetidoException() {
        this(MESSAGE);
    }

    public ProyectoRepetidoException(String mensaje) {
        super(mensaje);
    }
}
