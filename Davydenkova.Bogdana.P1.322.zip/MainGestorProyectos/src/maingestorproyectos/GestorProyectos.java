package maingestorproyectos;

import java.util.ArrayList;
import java.util.List;

public class GestorProyectos {

    private String nombre;
    private List<Proyecto> proyectos;

    public GestorProyectos(String nombre) {
        this.nombre = nombre;
        proyectos = new ArrayList<>();
    }
    
    public void agregarProyecto(Proyecto proyecto) {
        checkNull(proyecto, "Proyecto nulo");
        if (proyectos.contains(proyecto)) {
            throw new ProyectoRepetidoException();
        } else {
            proyectos.add(proyecto);
        }
    }

    private void checkNull(Object o, String mensaje) {
        if (o == null) {
            throw new IllegalArgumentException((mensaje == null) ? "Objeto nulo" : mensaje);
        }
    }
    
    public void mostrarProyectos(){
        mostrarProyectosLista(proyectos);
    }
    
    private void mostrarProyectosLista(List<Proyecto> lista) {
        StringBuilder sb = new StringBuilder();
        String sep = Utils.sepHorizontal(Utils.getHeaderTable().length() - 1);

        sb.append(sep);
        sb.append(Utils.getHeaderTable());
        sb.append(sep);

        for (Proyecto p : lista) {
            sb.append(p.mostrarProyecto());
        }
        sb.append(sep);
        System.out.println(sb.toString());
    }
    
    public void actualizarResultadosProyectos() {
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable a) {
                a.actualizarResultados();
            } else {
                System.out.println("El proyecto " + p.getNombre() + " no puede actualizarse");
            }
        }
    }
    
    private boolean hayModificacion(EstadoActual nuevoEstado){
        boolean modificacion = true;
        if(nuevoEstado == null || proyectos.isEmpty()){
            modificacion = false;
        }
        return modificacion;
    }
    
    public void actualizarEstadoProyectos(EstadoActual nuevoEstado){
        if(!(hayModificacion(nuevoEstado))){
            System.out.println("No se realizó ninguna modificación");
        }else{
            int cantidad = 0;
            List<Proyecto> lista = new ArrayList<>();
            for(Proyecto p : proyectos){
                p.setEstadoActual(nuevoEstado);
                lista.add(p);
                cantidad ++;
            }
            System.out.println("Cantidad total actualizada " + cantidad);
            mostrarProyectosLista(lista);
        }
        
    }

}
