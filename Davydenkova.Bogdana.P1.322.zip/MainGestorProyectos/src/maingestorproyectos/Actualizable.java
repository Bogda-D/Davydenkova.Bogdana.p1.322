package maingestorproyectos;

public interface Actualizable {
    
    void actualizarResultados();
}
