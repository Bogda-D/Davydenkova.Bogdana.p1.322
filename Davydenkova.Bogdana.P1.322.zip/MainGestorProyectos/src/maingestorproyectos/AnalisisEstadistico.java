package maingestorproyectos;

public class AnalisisEstadistico extends Proyecto implements Actualizable{
    
    private TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoActual estadoActual, TipoAnalisis tipoAnalisis) {
        super(nombre, equipoResponsable, estadoActual);
        this.tipoAnalisis = tipoAnalisis;
    }

    public String mostrarProyecto() {
        return super.mostrarProyecto() + "Tipo de analisis %-12s |\n".formatted(tipoAnalisis);
    }
    
    @Override
    public void actualizarResultados() {
        System.out.println("Actualizando el proyecto " + getNombre());
    }
}
