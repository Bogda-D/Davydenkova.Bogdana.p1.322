package maingestorproyectos;

public class Utils {
    public static String getHeaderTable() {
        return "|%-28s|%15s|%20s|%-30s|\n".formatted("NOMBRE", "EQUIPO RESPONSABLE", 
                "ESTADO ACTUAL", "ATRIBUTO ESPECIFICO");
    }
    
    public static String sepHorizontal(int length, char caracter){
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < length; i++){
            sb.append(caracter);
        }
        sb.append('\n');
        
        return sb.toString();
    }
    
    public static String sepHorizontal(int length){
        return sepHorizontal(length, '-');
    }
}
