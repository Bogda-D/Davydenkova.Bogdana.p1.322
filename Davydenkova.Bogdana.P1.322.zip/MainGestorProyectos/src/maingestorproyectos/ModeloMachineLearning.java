package maingestorproyectos;

public class ModeloMachineLearning extends Proyecto implements Actualizable {

    private static int PORCENTAJE_PRECISION_MIN = 0;
    private static int PORCENTAJE_PRECISION_MAX = 100;
    private int porcentajePrecision;

    public ModeloMachineLearning(String nombre, String equipoResponsable, EstadoActual estadoActual, int porcentajePrecision) {
        super(nombre, equipoResponsable, estadoActual);
        this.porcentajePrecision = validarPorcentajePrecision(porcentajePrecision);
    }

    private int validarPorcentajePrecision(int porcentaje) {
        if (porcentaje < PORCENTAJE_PRECISION_MIN || porcentaje > PORCENTAJE_PRECISION_MAX) {
            throw new IllegalArgumentException("Porcentaje de precision fuera de rango");
        } else {
            return porcentaje;
        }
    }

    public String mostrarProyecto() {
        return super.mostrarProyecto() + "Porcentaje de Precision %-5s |\n".formatted(porcentajePrecision);
    }

    @Override
    public void actualizarResultados() {
        System.out.println("Actualizando el proyecto " + getNombre());
    }
}
