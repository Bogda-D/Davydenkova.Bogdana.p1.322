package maingestorproyectos;

public enum EstadoActual {
    EN_DESARROLLO, 
    ENTRENANDO_MODELO, 
    FINALIZADO
}
