package maingestorproyectos;

public class MainGestorProyectos {

    public static void main(String[] args) {
        
        GestorProyectos gestor = new GestorProyectos("Gestor Pepe");
        
        cargarGestor(gestor);
        gestor.mostrarProyectos();
        gestor.actualizarResultadosProyectos();
        gestor.actualizarEstadoProyectos(null);
        
    }
    
    public static void cargarGestor(GestorProyectos g){
        g.agregarProyecto(new ModeloMachineLearning("ML Preciso", "Alfa", EstadoActual.EN_DESARROLLO, 90));
        g.agregarProyecto(new ModeloMachineLearning("ML mas preciso", "Beta", EstadoActual.EN_DESARROLLO, 95));
        g.agregarProyecto(new SistemaVisualizacion("SV Uno", "Gamma", EstadoActual.ENTRENANDO_MODELO,2));
        g.agregarProyecto(new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-B", EstadoActual.EN_DESARROLLO, TipoAnalisis.PREDICTIVO));
    }
    
}
